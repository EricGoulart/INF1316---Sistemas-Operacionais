// Eric Goulart da Cunha 2110878
// João Pedro Biscaia Fernandes 2110361

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <string.h>

void exibe_info(char* caminho_do_arq){
    struct stat inf_do_arq;
    if (stat(caminho_do_arq, &inf_do_arq) == 0) {
        printf("=================================\n");
        printf("Atributos do arquivo %s:\n", caminho_do_arq);
        printf("=================================\n");
        printf("Id do usuário: %u\n", (unsigned int) inf_do_arq.st_uid);
        printf("Último acesso: %s", ctime(&inf_do_arq.st_atime));
        printf("Última modificação: %s", ctime(&inf_do_arq.st_mtime));
        printf("Última modificação dos metadados: %s", ctime(&inf_do_arq.st_ctime));
        printf("Tamanho: %lld bytes\n", (long long) inf_do_arq.st_size);
        printf("Número inode: %lu\n", (unsigned long) inf_do_arq.st_ino);
        printf("Permissões: %o \n\n", (inf_do_arq.st_mode));
    }
    else {
      perror("Erro ao tentar ler arquivo");
      exit(1);
    }
    return;
}

void print_conteudo_arq(FILE * f){
  char caracter;
  while ((caracter = getc(f)) != EOF) {
    printf("%c",caracter);
  }
  printf("\n");
    
}

void altera_arq(FILE *arq, char *str, int n){

    if (fseek(arq, n, SEEK_SET) != 0) {
      perror("Erro ao reposicionar");
      exit(1);
    }

    fprintf(arq, "%s", str);

    if (fseek(arq, 0, SEEK_SET) != 0) {
      perror("Erro ao reposicionar");
      exit(1);
    }
    return;
}


void altera_permissao(char* caminho_do_arq){
  if (chmod(caminho_do_arq, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH ) != 0) {
    perror("Erro ao alterar as permissões\n");
  } else {
    printf("Permissões alteradas com sucesso.\n");
  }
  return;
} 

void print_subdiretorios(char *base_path, int contador) {
  struct dirent *entry;
  DIR *dir;
  if (!(dir = opendir(base_path))) {
    perror("Erro ao abrir diretório");
    exit(1); 
  }
  while ((entry = readdir(dir)) != NULL) {
    if (entry->d_type == DT_DIR) {
      if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
        continue;
      }

      char path[4096];
      snprintf(path, sizeof(path), "%s/%s", base_path, entry->d_name);
      printf("diretorio %d: %s\n",contador,entry->d_name);
      print_subdiretorios(path,++contador);
    }
  }
  closedir(dir);
}

int main() {
    char *caminho_do_arq = "so/c/arqc.txt";
    char *str = "Arq alterado com sucesso";

    exibe_info(caminho_do_arq);

    FILE * arq;
    arq = fopen("so/c/arqc.txt", "r+");
    if(!arq){
      perror("erro ao abrir o arquivo para leitura\n");
      exit(1);
    }

    printf("CONTEUDO do arquivo %s: ", caminho_do_arq);
    print_conteudo_arq(arq);
    printf("\n");

    altera_arq(arq,str,0);
  
    printf("CONTEUDO do arquivo %s ALTERADO: ", caminho_do_arq);
    print_conteudo_arq(arq);
    printf("\n");

    altera_permissao(caminho_do_arq); 

    exibe_info(caminho_do_arq);
 
    if (fclose(arq) != 0) {
      perror("Erro ao fechar o arquivo\n");
      exit(1);
    }
    print_subdiretorios("so",1);
      return 0;
}